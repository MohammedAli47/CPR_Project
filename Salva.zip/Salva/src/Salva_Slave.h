#ifndef SALVA_SLAVE_H_
#define SALVA_SLAVE_H_
#define Salva_u8AtMegaSlaveAddress 0x08
#include <Wire.h>
#include "HAL/VoltSensor/voltSensor_interface.h"
#include "HAL/Switches/switches_interface_Slave.h"
#include "HAL/ServoMotor/servoMotor_interface.h"
#include "HAL/StepperMotor/stepperMotor_interface.h"

class SalvaSlaveMC
{
public:
    void SalvaSlaveMC_voidInit()
    {
        Wire.begin();
        Serial.begin(115200);
        stepperMotor_voidInit();
    }

    void SalvaSlaveMC_voidSwitches()
    {
        switches_voidSwitchModeReceiver();
    }
};

#endif
