#ifndef SALVA_SLAVE_H_
#define SALVA_SLAVE_H_
#define Salva_u8AtMegaSlaveAddress 0x08
#include <Wire.h>
#include <Servo.h>
#include <trajfactory.h>
#include "LIB/ventSettings.h"
#include "HAL/VoltSensor/voltSensor_interface.h"
#include "HAL/Switches/switches_interface_Slave.h"
#include "HAL/ServoMotor/servoMotor_interface.h"
#include "HAL/StepperMotor/stepperMotor_interface.h"
#endif
