#ifndef ERRORTYPES_H_
#define ERRORTYPES_H_

typedef enum {
  ES_FAILURE = -1,
  ES_SUCCESS,
  ES_NULL_POINTER,
  ES_OUT_OF_RANGE
} ES_Type;

template <typename... _typenameArguments, typename _typenameArgument1, typename _typenameArgument2, typename _typenameArgument3>
ES_Type errorTypes_enuDebuggerNonVoidFunction(void (*Copy_enuFunction)(_typenameArguments...), const char* Copy_strNameOfFunction, bool Copy_boolTimeStamps, u8 Copy_u8ArgumentCount, ...);
ES_Type errorTypes_enuDebuggerVoidFunction(void (*Copy_enuFunction)(void), const char* Copy_strNameOfFunction, bool Copy_boolTimeStamps);

#endif
