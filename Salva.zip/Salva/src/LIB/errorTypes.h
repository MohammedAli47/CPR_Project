#ifndef ERRORTYPES_H_
#define ERRORTYPES_H_

typedef enum
{
    ES_FAILURE = -1,
    ES_SUCCESS,
    ES_NULL_POINTER,
    ES_OUT_OF_RANGE
} ES_Type;

class ErrorTypesDebugger
{
private:
    u8 ErrorTypesDebugger_u8LevelOfAbstraction = 0;
    u32 ErrorTypesDebugger_u32ExecutionTime;
    ES_Type ErrorTypesDebugger_enuErrorState;

public:
    void errorTypes_voidAbstractionViewer();
    ES_Type errorTypes_enuDebuggerBeforeVoidFunction(const char *Copy_strNameOfFunction);
    ES_Type errorTypes_enuDebuggerAfterVoidFunction(const char *Copy_strNameOfFunction, bool Copy_boolTimeStamps);
};

extern ErrorTypesDebugger Salva_Debugger;

#endif
