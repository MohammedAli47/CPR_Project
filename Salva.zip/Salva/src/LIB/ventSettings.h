#ifndef VENTSETTINGS_H_
#define VENTSETTINGS_H_

typedef struct
{
    u8 ventSettings_u8Mode = 'L';
    u16 ventSettings_u16TidalVolume = 500;
    u16 ventSettings_u16RespirationRate = 12;
    u16 ventSettings_u16Inhale = 1;
    u16 ventSettings_u16Exhale = 3;
    u16 ventSettings_u16HoldSeconds = 0;
    u16 ventSettings_u16HoldDecimals = 0;
    u16 ventSettings_u16DeltaTime = 20;
    u8 ventSettings_u8Hours = 0;
    u8 ventSettings_u8Minutes = 0;
    u8 ventSettings_u8Seconds = 0;
    bool ventSettings_boolSend = true;
} VentSettings;

typedef struct
{
    u16 ventLimits_u16MinTidalVolume = 300;
    u16 ventLimits_u16MaxTidalVolume = 700;
    u8 ventLimits_u8DeltaTidalVolume = 50;
    u8 ventLimits_u8MinRespirationRate = 10;
    u8 ventLimits_u8MaxRespirationRate = 30;
    u8 ventLimits_u8DeltaRespirationRate = 1;
    u8 ventLimits_u8MinExhale = 1;
    u8 ventLimits_u8MaxExhale = 5;
    u8 ventLimits_u8DeltaExhale = 1;
} VentLimits;

#endif
