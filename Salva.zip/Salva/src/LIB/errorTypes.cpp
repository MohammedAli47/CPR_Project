#include "Arduino.h"
#include "stdTypes.h"
#include "errorTypes.h"

ErrorTypesDebugger Salva_Debugger;

void ErrorTypesDebugger::errorTypes_voidAbstractionViewer()
{
    for (u8 Local_u8Iterator = 0; Local_u8Iterator < ErrorTypesDebugger::ErrorTypesDebugger_u8LevelOfAbstraction; Local_u8Iterator++)
    {
        Serial.print(" ");
    }
}

ES_Type ErrorTypesDebugger::errorTypes_enuDebuggerBeforeVoidFunction(const char *Copy_strNameOfFunction)
{
    ErrorTypesDebugger::errorTypes_voidAbstractionViewer();
    Serial.print(Copy_strNameOfFunction);
    Serial.println(" Function Started.");
    ErrorTypesDebugger::ErrorTypesDebugger_enuErrorState = ES_FAILURE;
    ErrorTypesDebugger::ErrorTypesDebugger_u32ExecutionTime = millis();
    ErrorTypesDebugger::ErrorTypesDebugger_u8LevelOfAbstraction++;
}

ES_Type ErrorTypesDebugger::errorTypes_enuDebuggerAfterVoidFunction(const char *Copy_strNameOfFunction, bool Copy_boolTimeStamps)
{
    ErrorTypesDebugger::ErrorTypesDebugger_u8LevelOfAbstraction--;
    ErrorTypesDebugger::ErrorTypesDebugger_enuErrorState = ES_SUCCESS;
    ErrorTypesDebugger::errorTypes_voidAbstractionViewer();
    Serial.print(Copy_strNameOfFunction);
    Serial.println(" Function Ended.");
    if (Copy_boolTimeStamps)
    {
        ErrorTypesDebugger::errorTypes_voidAbstractionViewer();
        Serial.print("Execution Time: ");
        Serial.print(millis() - ErrorTypesDebugger::ErrorTypesDebugger_u32ExecutionTime);
        Serial.println("ms");
    }
    return ErrorTypesDebugger::ErrorTypesDebugger_enuErrorState;
}
