#include "stdTypes.h"
#include "errorTypes.h"

template <typename... _typenameArguments, typename _typenameArgument1, typename _typenameArgument2, typename _typenameArgument3>
ES_Type errorTypes_enuDebuggerNonVoidFunction(void (*Copy_enuFunction)(_typenameArguments...), const char* Copy_strNameOfFunction, bool Copy_boolTimeStamps, u8 Copy_u8ArgumentCount, ...)
{
    Serial.print(Copy_strNameOfFunction);
    Serial.println(" Function Started.");
    ES_Type Local_enuErrorState = ES_FAILURE;
    u32 Local_u32ExecutionTime = millis();
    va_list Local_VaList;
    va_start(Local_VaList, Copy_u8ArgumentCount);
    _typenameArgument1 Local_typenameArgument1 = va_arg(Local_VaList, _typenameArgument1);
    _typenameArgument2 Local_typenameArgument2 = va_arg(Local_VaList, _typenameArgument2);
    _typenameArgument3 Local_typenameArgument3 = va_arg(Local_VaList, _typenameArgument3);
    Copy_enuFunction(Local_typenameArgument1, Local_typenameArgument2, Local_typenameArgument3);
    va_end(Local_VaList);
    Local_enuErrorState = ES_SUCCESS;
    Serial.print(Copy_strNameOfFunction);
    Serial.println(" Function Ended.");
    if (Copy_boolTimeStamps)
    {
        Serial.print("Execution Time: ");
        Serial.println(millis() - Local_u32ExecutionTime);
    }
    return Local_enuErrorState;
}

ES_Type errorTypes_enuDebuggerVoidFunction(void (*Copy_enuFunction)(void), const char* Copy_strNameOfFunction, bool Copy_boolTimeStamps)
{
    Serial.print(Copy_strNameOfFunction);
    Serial.println(" Function Started.");
    ES_Type Local_enuErrorState = ES_FAILURE;
    u32 Local_u32ExecutionTime = millis();
    Copy_enuFunction();
    Local_enuErrorState = ES_SUCCESS;
    Serial.print(Copy_strNameOfFunction);
    Serial.println(" Function Ended.");
    if (Copy_boolTimeStamps)
    {
        Serial.print("Execution Time: ");
        Serial.println(millis() - Local_u32ExecutionTime);
    }
    return Local_enuErrorState;
}
