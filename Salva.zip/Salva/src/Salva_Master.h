#ifndef SALVA_MASTER_H_
#define SALVA_MASTER_H_
#define Salva_u8AtMegaSlaveAddress 0x08
#include <Wire.h>
#include "HAL/Encoder/encoder_interface.h"
#include "HAL/LCD/liquidCrystal_interface.h"
#include "HAL/Switches/switches_interface_Master.h"
#include "HAL/StepperMotor/stepperMotor_interface.h" 
#include "HAL/HeartRateSensor/heartRateSensor_interface.h" 

class SalvaMasterMC
{
private:
    SwitchesTransmitter Salva_Switches;
    LiquidCrystal_I2C Salva_LCD(liquidCrystal_u8LCDSlaveAddress, liquidCrystal_u8NumberOfColumns, liquidCrystal_u8NumberOfRows);
    RotaryEncoder Salva_Encoder(encoder_u8DTPin, encoder_u8CLKPin, RotaryEncoder::LatchMode::TWO03);

public:
    void SalvaMasterMC_voidInit()
    {
        Wire.begin();
        Serial.begin(115200);
        errorTypes_enuDebuggerVoidFunction(stepperMotor_voidInit, "Stepper Initializer", false);
        errorTypes_enuDebuggerVoidFunction(Salva_Encoder.encoder_voidInit, "Encoder Initializer", false);
        errorTypes_enuDebuggerVoidFunction(Salva_Switches.switches_voidInit, "Switches Initializer", false);
        errorTypes_enuDebuggerVoidFunction(Salva_LCD.liquidCrystal_voidInit, "LCD Initializer", false);
        errorTypes_enuDebuggerVoidFunction(heartRateSensor_voidInit, "Heart Rate Sensor Initializer", true);
    }

    void SalvaMasterMC_voidSwitches()
    {
        
    }
};

#endif
