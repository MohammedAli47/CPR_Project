#ifndef SALVA_MASTER_H_
#define SALVA_MASTER_H_
#define Salva_u8AtMegaSlaveAddress 0x09
#include <Wire.h>
#include "RTClib.h"
#include "HAL/Encoder/encoder_interface.h"
#include "HAL/LCD/liquidCrystal_interface.h"
#include "HAL/Switches/switches_interface_Master.h"
#include "HAL/HeartRateSensor/heartRateSensor_interface.h"
#endif
