#ifndef SWITCHES_CONFIG_H_
#define SWITCHES_CONFIG_H_

#define switches_u8Switch1 11
#define switches_u8Switch2 9

#endif