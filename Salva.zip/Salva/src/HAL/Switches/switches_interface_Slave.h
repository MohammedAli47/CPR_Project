#ifndef SWITCHES_INTERFACE_SLAVE_H_
#define SWITCHES_INTERFACE_SLAVE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "switches_private.h"
#include "HAL/LCD/liquidCrystal_interface.h"

class SwitchesReceiver
{
private:
    switches_enuStates switches_enuOverallSwitchesState;

public:
    void switches_voidSwitchModeReceiver(void);
    void switches_voidSwitchesStateSetter(u8 Copy_u8State);
};

#endif
