#ifndef SWITCHES_INTERFACE_SLAVE_H_
#define SWITCHES_INTERFACE_SLAVE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "switches_private.h"

class SwitchesReceiver
{
public:
    u8 Salva_u8ReceivedI2CSpecialCode;
    switches_enuStates switches_enuOverallSwitchesState;
    void switches_voidSwitchModeReceiver(void);
};

#endif
