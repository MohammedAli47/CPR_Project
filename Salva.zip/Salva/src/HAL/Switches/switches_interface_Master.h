#ifndef SWITCHES_INTERFACE_MASTER_H_
#define SWITCHES_INTERFACE_MASTER_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "switches_config.h"
#include "switches_private.h"
#include "HAL/LCD/liquidCrystal_interface.h"

class SwitchesTransmitter
{
private:
    u8 switches_u8Switch1State = 0, switches_u8Switch2State = 0;

public:
    u8 switches_u8Mode;
    void switches_voidInit();
    void switches_voidSwitchModeTransmitter();
};

#endif
