#ifndef SWITCHES_INTERFACE_MASTER_H_
#define SWITCHES_INTERFACE_MASTER_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "switches_config.h"

class SwitchesTransmitter
{
public:
    void switches_voidInit(void);
    void switches_voidSwitchModeTransmitter(void);
};

#endif
