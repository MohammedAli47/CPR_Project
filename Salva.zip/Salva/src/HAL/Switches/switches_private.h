#ifndef SWITCHES_PRIVATE_H_
#define SWITCHES_PRIVATE_H_

#define Salva_u8AtMegaSlaveAddress 0x08

typedef enum
{
    switches_enuNoSwitchIsPressed,
    switches_enuSwitch1IsPressed,
    switches_enuSwitch2IsPressed,
    switches_enuAllSwitchesArePressed
} switches_enuStates;

#endif
