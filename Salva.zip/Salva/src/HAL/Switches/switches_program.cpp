#include "Arduino.h"
#include <Wire.h>
#include "LIB/ventSettings.h"
#include "switches_interface_Master.h"
#include "switches_interface_Slave.h"
#include "HAL/Encoder/encoder_interface.h"
#include "HAL/StepperMotor/stepperMotor_interface.h"
#include "HAL/ServoMotor/servoMotor_interface.h"

void SwitchesTransmitter::switches_voidInit()
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Switches Initializer");
    pinMode(switches_u8Switch1, INPUT);
    pinMode(switches_u8Switch2, INPUT);
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Switches Initializer", false);
}

void SwitchesTransmitter::switches_voidSwitchModeTransmitter()
{
    VentSettings SalvaVentSettings;
    VentLimits SalvaVentLimits;
    u16 cal[9] = {950, 1062, 1155, 1238, 1320, 1393, 1465, 1538, 1610};
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Switches Mode Transmitter");
    // For Timing Purposes (Loop Breaks After 5 Seconds)
    Salva_LCD.liquidCrystal_voidPositionUpdate(4, 2);
    Salva_LCD.print("Please Press");
    Salva_LCD.liquidCrystal_voidPositionUpdate(5, 3);
    Salva_LCD.print("Any Button");
    u16 Local_u16ExecutionTime = millis();
    while (!digitalRead(switches_u8Switch1) || !digitalRead(switches_u8Switch2))
    {
        if (digitalRead(switches_u8Switch1))
        {
            SwitchesTransmitter::switches_u8Switch1State = switches_enuSwitch1IsPressed;
        }
        else if (digitalRead(switches_u8Switch2))
        {
            SwitchesTransmitter::switches_u8Switch2State = switches_enuSwitch2IsPressed;
        }
        else if (millis() - Local_u16ExecutionTime >= 5000)
        {
            break;
        }
        else
        {
            /* Do Nothing */
        }
    }
    Salva_LCD.clear();
    u8 Local_u8OverallSwitchesState = SwitchesTransmitter::switches_u8Switch1State + SwitchesTransmitter::switches_u8Switch2State;
    switches_u8Mode = Local_u8OverallSwitchesState;
    Wire.beginTransmission(Salva_u8AtMegaSlaveAddress);
    Wire.write((switches_enuStates)Local_u8OverallSwitchesState);
    Wire.endTransmission();
    if (Local_u8OverallSwitchesState == switches_enuSwitch2IsPressed)
    {
        encoder_voidInputTidalVolume(encoder_u16TVMinValue, encoder_u8TVMultiplier, encoder_u16TVMaximumValue, encoder_u8RequestedValueTV);
        encoder_voidInputRespiratoryRate(encoder_u8RRMinValue, encoder_u8RRMultiplier, encoder_u8RRMaximumValue, encoder_u8RequestedValueRR);
        encoder_voidInputIERatioExpiratoryValue(encoder_enuIERatioInspiratoryValue, encoder_enuIERatioMultiplier, encoder_enuIERatioExpiratoryValueAbnormal2, encoder_u8RequestedValueEX);
        if (SalvaVentSettings.ventSettings_boolSend)
        {
            Wire.beginTransmission(Salva_u8AtMegaSlaveAddress);
            Serial.println(Wire.write(SalvaVentSettings.ventSettings_u8Mode));
            if (SalvaVentSettings.ventSettings_u8Mode == servoMotor_u8CommandBuild)
            {
                SalvaVentSettings.ventSettings_u16TidalVolume = Salva_Encoder.encoder_u16GetValue(encoder_u8RequestedValueTV);
                SalvaVentSettings.ventSettings_u16RespirationRate = Salva_Encoder.encoder_u16GetValue(encoder_u8RequestedValueRR);
                SalvaVentSettings.ventSettings_u16Exhale = Salva_Encoder.encoder_u16GetValue(encoder_u8RequestedValueEX);
                u16 Local_u16Setpoint = cal[(SalvaVentSettings.ventSettings_u16TidalVolume - SalvaVentLimits.ventLimits_u16MinTidalVolume) / SalvaVentLimits.ventLimits_u8DeltaTidalVolume];
                Wire.write(byte(Local_u16Setpoint >> 8));
                Wire.write(byte(Local_u16Setpoint & 0x00FF));
                Wire.write(byte(SalvaVentSettings.ventSettings_u16RespirationRate));
                Wire.write(byte(SalvaVentSettings.ventSettings_u16Inhale));
                Wire.write(byte(SalvaVentSettings.ventSettings_u16Exhale));
                Wire.write(byte(SalvaVentSettings.ventSettings_u16HoldSeconds));
                Wire.write(byte(SalvaVentSettings.ventSettings_u16HoldDecimals));
                Wire.write(byte(SalvaVentSettings.ventSettings_u16DeltaTime));
                SalvaVentSettings.ventSettings_u8Mode = servoMotor_u8CommandStart;
            }
            else
            {
                /* Do Nothing */
            }
            SalvaVentSettings.ventSettings_boolSend = false;
            Wire.endTransmission();
        }
        else
        {
            /* Do Nothing */
        }
    }
    else
    {
        /* Do Nothing */
    }
    SwitchesTransmitter::switches_u8Switch1State = 0;
    SwitchesTransmitter::switches_u8Switch2State = 0;
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Switches Mode Transmitter", true);
}

void SwitchesReceiver::switches_voidSwitchModeReceiver(void)
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Switches Mode Receiver");
    switch (SwitchesReceiver::switches_enuOverallSwitchesState)
    {
    case switches_enuNoSwitchIsPressed:
        /* Do Nothing */
        break;
    case switches_enuSwitch1IsPressed:
        stepperMotor_voidMotorDriver(stepperMotor_u8NumberOfRotationsMODE1);
        break;
    case switches_enuSwitch2IsPressed:
        stepperMotor_voidMotorDriver(stepperMotor_u8NumberOfRotationsMODE2);
        u32 Local_u32ExecutionTime = millis();
        while (true)
        {
            if (millis() - Local_u32ExecutionTime >= 5000)
            {
                break;
            }
            Serial.println(millis());
            Serial.println(Local_u32ExecutionTime);
            Salva_Servo.servoMotor_voidMotorDriver();
        }
        break;
    case switches_enuAllSwitchesArePressed:
        /* Do Nothing */
        break;
    default:
        /* Do Nothing */
        break;
    }
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Switches Mode Receiver", true);
}

void SwitchesReceiver::switches_voidSwitchesStateSetter(u8 Copy_u8State)
{
    switch (Copy_u8State)
    {
    case switches_enuNoSwitchIsPressed:
        SwitchesReceiver::switches_enuOverallSwitchesState = switches_enuNoSwitchIsPressed;
        break;
    case switches_enuSwitch1IsPressed:
        SwitchesReceiver::switches_enuOverallSwitchesState = switches_enuSwitch1IsPressed;
        break;
    case switches_enuSwitch2IsPressed:
        SwitchesReceiver::switches_enuOverallSwitchesState = switches_enuSwitch2IsPressed;
        break;
    case switches_enuAllSwitchesArePressed:
        SwitchesReceiver::switches_enuOverallSwitchesState = switches_enuAllSwitchesArePressed;
        break;
    default:
        /* Do Nothing */
        break;
    }
}
