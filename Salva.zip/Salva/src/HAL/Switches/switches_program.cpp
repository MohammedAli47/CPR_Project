#include "Arduino.h"
#include <Wire.h>
#include "switches_interface_Master.h"
#include "switches_interface_Slave.h"
#include "HAL/StepperMotor/stepperMotor_interface.h"
#include "HAL/ServoMotor/servoMotor_interface.h"

void SwitchesTransmitter::switches_voidInit()
{
  pinMode(switches_u8Switch1, INPUT);
  pinMode(switches_u8Switch2, INPUT);
}

void SwitchesTransmitter::switches_voidSwitchModeTransmitter(void)
{
  u8 Local_u8Switch1State = digitalRead(switches_u8Switch1) ? 1 : 0;
  u8 Local_u8Switch2State = digitalRead(switches_u8Switch2) ? 2 : 0;
  delay(100);
  Serial.print("Switch 1: ");
  Serial.println(Local_u8Switch1State);
  Serial.print("Switch 2: ");
  Serial.println(Local_u8Switch2State);
  u8 Local_u8OverallSwitchesState = Local_u8Switch1State + Local_u8Switch2State;
  Wire.beginTransmission(Salva_u8AtMegaSlaveAddress);
  Wire.write(switches_u8I2CSpecialCode);
  Wire.write((switches_enuStates)Local_u8OverallSwitchesState);
  Wire.endTransmission();
}

void SwitchesReceiver::switches_voidSwitchModeReceiver(void)
{
  Wire.requestFrom(Salva_u8AtMegaSlaveAddress, 2);
  while (Wire.available())
  {
    SwitchesReceiver::Salva_u8ReceivedI2CSpecialCode = Wire.read();
    SwitchesReceiver::switches_enuOverallSwitchesState = (switches_enuStates)Wire.read();
  }
  if (SwitchesReceiver::Salva_u8ReceivedI2CSpecialCode == switches_u8I2CSpecialCode)
  {
    switch (SwitchesReceiver::switches_enuOverallSwitchesState)
    {
    case switches_enuNoSwitchIsPressed:
      /* Do Nothing */
      break;
    case switches_enuSwitch1IsPressed:
      stepperMotor_voidMotorDriver(stepperMotor_u8NumberOfRotationsMODE1);
      break;
    case switches_enuSwitch2IsPressed:
      stepperMotor_voidMotorDriver(stepperMotor_u8NumberOfRotationsMODE2);
      break;
    case switches_enuAllSwitchesArePressed:
      /* Do Nothing */
      break;
    default:
      /* Do Nothing */
      break;
    }
  }
  else
  {
    /* Do Nothing */
  }
}
