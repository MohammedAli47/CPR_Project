#ifndef HEARTRATESENSOR_PRIVATE_H_
#define HEARTRATESENSOR_PRIVATE_H_

// Placeholder

#endif