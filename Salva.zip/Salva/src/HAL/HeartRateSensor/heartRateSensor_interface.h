#ifndef HEARTRATESENSOR_INTERFACE_H_
#define HEARTRATESENSOR_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "heartRateSensor_config.h"
#include "heartRateSensor_private.h"
#include "HAL/LCD/liquidCrystal_interface.h"
#include <Wire.h>
#include "MAX30105.h"
#include "heartRate.h"

class SalvaHeartSensor : MAX30105
{
public:
    void heartRateSensor_voidInit(SalvaHeartSensor &Salva_HeartSensor);
    void heartRateSensor_voidBPMCalculator(SalvaHeartSensor &Salva_HeartSensor);
};

#endif
