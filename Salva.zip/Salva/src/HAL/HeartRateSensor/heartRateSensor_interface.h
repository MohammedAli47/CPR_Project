#ifndef HEARTRATESENSOR_INTERFACE_H_
#define HEARTRATESENSOR_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "heartRateSensor_config.h"
#include "heartRateSensor_private.h"
#include <Wire.h>
#include "MAX30105.h"
#include "heartRate.h"

void heartRateSensor_voidInit(void);
void heartRateSensor_voidBPMCalculator(void);

#endif
