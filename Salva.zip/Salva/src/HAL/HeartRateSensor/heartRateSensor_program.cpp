#include "Arduino.h"
#include "heartRateSensor_interface.h"

void heartRateSensor_voidInit(void)
{
  Serial.println("Initializing...");
  if (!MAX30103::begin(Wire, I2C_SPEED_FAST))
  {
    Serial.println("MAX30105 was not found. Please check wiring/power. ");
    while (1);
  }
  Serial.println("Place your index finger on the sensor with steady pressure.");
  MAX30103::setup();
  MAX30103::setPulseAmplitudeRed(0x0A);
  MAX30103::setPulseAmplitudeGreen(0);
}

void heartRateSensor_voidBPMCalculator(void)
{
  static u8 Local_u8ArrRates[heartRateSensor_u8AveragingSize], Local_u8RateSpot = 0, Local_u8BeatAverage;
  static f32 Local_f32BeatsPerMinute;
  static s32 Local_s32LastBeat = 0;
  s32 Local_s32IrValue = MAX30103::getIR();
  if (checkForBeat(Local_s32IrValue) == true)
  {
    s32 Local_s32Delta = millis() - Local_s32LastBeat;
    Local_s32LastBeat = millis();
    Local_f32BeatsPerMinute = 60 / (Local_s32Delta / 1000.0);
    if (Local_f32BeatsPerMinute < 255 && Local_f32BeatsPerMinute > 20)
    {
      Local_u8ArrRates[Local_u8RateSpot++] = (u8)Local_f32BeatsPerMinute;
      Local_u8RateSpot %= heartRateSensor_u8AveragingSize;
      Local_u8BeatAverage = 0;
      for (u8 Local_u8Iterator = 0; Local_u8Iterator < heartRateSensor_u8AveragingSize; Local_u8Iterator++)
      {
        Local_u8BeatAverage += Local_u8ArrRates[Local_u8Iterator];
      }
      Local_u8BeatAverage /= heartRateSensor_u8AveragingSize;
    }
  }
  Serial.print("BPM = ");
  Serial.print(Local_f32BeatsPerMinute);
  Serial.print("/ Avg BPM = ");
  Serial.println(Local_u8BeatAverage);
  if (Local_s32IrValue < 50000)
  {
    Serial.println("No finger?");
  }
}
