#ifndef HEARTRATESENSOR_CONFIG_H_
#define HEARTRATESENSOR_CONFIG_H_

#define heartRateSensor_u8AveragingSize 4

#endif