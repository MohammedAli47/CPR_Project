#ifndef VOLTSENSOR_INTERFACE_H_
#define VOLTSENSOR_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "voltSensor_config.h"
#include "voltSensor_private.h"

class VoltSensor {
public:
  u8 voltSensor_u8Reading;
  void VoltSensor_voidGetReading(void);
};

#endif
