#ifndef VOLTSENSOR_PRIVATE_H_
#define VOLTSENSOR_PRIVATE_H_

#define voltSensor_u8SensorConversion   ((f32)voltSensor_u8ADCHighestValue / (f32)voltSensor_u8MaxSensVoltRating)
#define voltSensor_u8HigherVoltEnd      (voltSensor_u8SensorConversion * (f32)voltSensor_u8HigherPercentageEnd)
#define voltSensor_u8LowerVoltEnd       (voltSensor_u8SensorConversion * (f32)voltSensor_u8LowerPercentageEnd)
#define voltSensor_u8Delta              (voltSensor_u8HigherVoltEnd - voltSensor_u8LowerVoltEnd)

#endif