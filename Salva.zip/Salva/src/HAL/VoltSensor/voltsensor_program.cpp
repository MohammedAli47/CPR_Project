#include "Arduino.h"
#include "voltSensor_interface.h"

void VoltSensor::voltSensor_voidInit(void)
{
    pinMode(voltSensor_u8ADCPin, INPUT);
}

u8 VoltSensor::voltSensor_u8GetReading(void)
{
  u16 Local_u16ADCReading = analogRead(voltSensor_u8ADCPin);
  VoltSensor::voltSensor_u8Reading = round(((Local_u16ADCReading <= voltSensor_u8LowerVoltEnd) ? 0 : (Local_u16ADCReading - voltSensor_u8LowerVoltEnd) / voltSensor_u8Delta) * 100.0);
  return constrain(VoltSensor::voltSensor_u8Reading, 0, 100);
}
