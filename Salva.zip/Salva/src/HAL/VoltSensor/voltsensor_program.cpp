#include "Arduino.h"
#include "voltSensor_interface.h"

void VoltSensor::VoltSensor_voidGetReading(void)
{
  u16 Local_u16ADCReading = analogRead(voltSensor_u8ADCPin);
  VoltSensor::voltSensor_u8Reading = round(((Local_u16ADCReading <= voltSensor_u8LowerVoltEnd) ? 0 : (Local_u16ADCReading - voltSensor_u8LowerVoltEnd) / voltSensor_u8Delta) * 100.0);
  Serial.print("Voltage Reading: ");
  Serial.println(VoltSensor::voltSensor_u8Reading);
}
