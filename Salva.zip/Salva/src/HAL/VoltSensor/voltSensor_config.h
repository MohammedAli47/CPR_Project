#ifndef VOLTSENSOR_CONFIG_H_
#define VOLTSENSOR_CONFIG_H_

#define voltSensor_u8ADCHighestValue        (0b1111111111)    // 10-bit resolution
#define voltSensor_u8MaxSensVoltRating      24
#define voltSensor_u8HigherPercentageEnd    12
#define voltSensor_u8LowerPercentageEnd     9
#define voltSensor_u8ADCPin                 A0

#endif