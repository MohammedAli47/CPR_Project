#ifndef SERVOMOTOR_PRIVATE_H_
#define SERVOMOTOR_PRIVATE_H_

#define servoMotor_u16Min           2400
#define servoMotor_u16Max           550
#define servoMotor_u8CommandStart   'O'
#define servoMotor_u8CommandStop    'X'
#define servoMotor_u8CommandBuild   'L'

#endif