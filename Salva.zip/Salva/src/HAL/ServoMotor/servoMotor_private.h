#ifndef SERVOMOTOR_PRIVATE_H_
#define SERVOMOTOR_PRIVATE_H_

#define sensConv        ((f32)ADC_highestValue / (f32)maxSensVoltRating)
#define higherVoltEnd   (sensConv * (f32)higherPercentageEnd)
#define lowerVoltEnd    (sensConv * (f32)lowerPercentageEnd)
#define delta           (higherVoltEnd - lowerVoltEnd)

#endif