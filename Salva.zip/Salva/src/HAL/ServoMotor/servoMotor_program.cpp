#include "Arduino.h"
#include "servoMotor_interface.h"

SalvaServo Salva_Servo1;
SalvaServo Salva_Servo2;

void SalvaServo::servoMotor_voidMotorDriver(void)
{
    switch (SalvaServo::servoMotor_u8State)
    {
    case servoMotor_u8CommandStart:
        SalvaServo::servoMotor_voidMoveTo(Trajectory_ptrTraj->nextStep(), Trajectory_ptrTraj->getDeltaTime());
        break;
    case servoMotor_u8CommandStop:
        SalvaServo::servoMotor_voidStop();
        break;
    case servoMotor_u8CommandBuild:
        SalvaServo::servoMotor_voidStop();
        if (Trajectory_ptrTraj != 0)
        {
            delete Trajectory_ptrTraj;
        }
        Trajectory_ptrTraj = tf.build(SalvaServo::servoMotor_u8RespiratoryRate, SalvaServo::servoMotor_f32IERate, SalvaServo::servoMotor_u8Setpoint, SalvaServo::servoMotor_f32Hold, SalvaServo::servoMotor_u8DeltaTime);
        SalvaServo::servoMotor_u8State = servoMotor_u8CommandStart;
        break;
    }
}

void SalvaServo::servoMotor_voidMoveTo(u16 Copy_u16Position, u8 Copy_u8DeltaTime)
{
    Serial.println(Copy_u16Position);
    // Note: 2 Servos moving dependent on each other
    Salva_Servo1.writeMicroseconds(servoMotor_u16Min - Copy_u16Position);
    delay(Copy_u8DeltaTime);
    Salva_Servo2.writeMicroseconds(servoMotor_u16Min - Copy_u16Position);
    delay(Copy_u8DeltaTime);
}

void SalvaServo::servoMotor_voidStop(void)
{
    if (Trajectory_ptrTraj != 0)
    {
        while (Trajectory_ptrTraj->getCurrentStep() != 0)
        {
            SalvaServo::servoMotor_voidMoveTo(Trajectory_ptrTraj->nextStep(), Trajectory_ptrTraj->getDeltaTime());
        }
    }
    else
    {
        SalvaServo::servoMotor_voidMoveTo(0, 100);
    }
}
