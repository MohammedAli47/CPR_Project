#ifndef SERVOMOTOR_INTERFACE_H_
#define SERVOMOTOR_INTERFACE_H_
#include <Servo.h>
#include <LIB/trajfactory.h>
#include "LIB/ventSettings.h"
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "servoMotor_config.h"
#include "servoMotor_private.h"

class SalvaServo : public Servo
{
private:
    TrajFactory tf = TrajFactory();
    Trajectory *Trajectory_ptrTraj = 0;
    void servoMotor_voidMoveTo(u16 Copy_u16Position, u8 Copy_u8DeltaTime);
    void servoMotor_voidStop(void);

public:
    u8 servoMotor_u8RespiratoryRate, servoMotor_u8Setpoint, servoMotor_u8DeltaTime, servoMotor_u8State;
    f32 servoMotor_f32IERate, servoMotor_f32Hold;
    void servoMotor_voidMotorDriver(void);
};

extern SalvaServo Salva_Servo1;
extern SalvaServo Salva_Servo2;

#endif
