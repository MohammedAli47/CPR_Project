#ifndef SERVOMOTOR_CONFIG_H_
#define SERVOMOTOR_CONFIG_H_

#define servoMotor_u8ServoPin 5

#endif