#ifndef SERVOMOTOR_CONFIG_H_
#define SERVOMOTOR_CONFIG_H_

#define servoMotor_u8Servo1Pin 6
#define servoMotor_u8Servo2Pin 5

#endif