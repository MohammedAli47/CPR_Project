#include "Arduino.h"
#include "encoder_interface.h"

SalvaEncoder Salva_Encoder;

void SalvaEncoder::encoder_voidInit()
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Encoder Initializer");
    pinMode(encoder_u8SWPin, INPUT);
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Encoder Initializer", false);
}

void SalvaEncoder::encoder_voidInputTemplate(u16 Copy_u16MinInput, u8 Copy_u8Multiplier, u16 Copy_u16MaximumInput, u16 Copy_16ActualReading)
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Encoder Input");
    Salva_Encoder.encoder_u16BaseReading = 0;
    while (!digitalRead(encoder_u8SWPin))
    {
        static u16 Local_u16Position = Copy_u16MinInput;
        Salva_Encoder.tick();
        Salva_Encoder.encoder_u16BaseReading += (Salva_Encoder.getPosition() * Copy_u8Multiplier);
        if (Local_u16Position != Salva_Encoder.encoder_u16BaseReading)
        {
            Salva_LCD.liquidCrystal_voidPositionUpdate(0, 1);
            Salva_LCD.print("Rotate The Encoder");
            Salva_LCD.liquidCrystal_voidPositionUpdate(0, 2);
            Salva_LCD.print("To Change The Value");
            Salva_LCD.liquidCrystal_voidPositionUpdate(0, 3);
            switch (Copy_16ActualReading)
            {
            case encoder_enuNoRequestedValue:
                /* Do Nothing */
                return;
                break;
            case encoder_enuRequestedValueTV:
                Salva_LCD.print("Tidal Volume: ");
                break;
            case encoder_enuRequestedValueRR:
                Salva_LCD.print("Respi Rate: ");
                break;
            case encoder_enuRequestedValueEX:
                Salva_LCD.print("IE Ratio Base: ");
                break;
            default:
                /* Do Nothing */
                break;
            }
            Salva_LCD.print(Salva_Encoder.encoder_u16BaseReading);
            Serial.print("Reading = ");
            Serial.println(Salva_Encoder.encoder_u16BaseReading);
            Serial.print("Direction: ");
            Serial.println((s8)(Salva_Encoder.getDirection()));
            Local_u16Position = Salva_Encoder.encoder_u16BaseReading >= Copy_u16MaximumInput ? Copy_u16MaximumInput : Salva_Encoder.encoder_u16BaseReading;
        }
    }
    switch (Copy_16ActualReading)
    {
    case encoder_enuNoRequestedValue:
        /* Do Nothing */
        return;
        break;
    case encoder_enuRequestedValueTV:
        Salva_Encoder.encoder_u16TidalVolume = Salva_Encoder.encoder_u16BaseReading;
        break;
    case encoder_enuRequestedValueRR:
        Salva_Encoder.encoder_u8RespiratoryRate = Salva_Encoder.encoder_u16BaseReading;
        break;
    case encoder_enuRequestedValueEX:
        Salva_Encoder.encoder_u8IERatioExpiratoryValue = Salva_Encoder.encoder_u16BaseReading;
        break;
    default:
        /* Do Nothing */
        break;
    }
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Encoder Input", true);
    delay(100);
}

u16 SalvaEncoder::encoder_u16GetValue(u16 Copy_u16RequestedValue)
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Get Value");
    switch (Copy_u16RequestedValue)
    {
    case encoder_enuNoRequestedValue:
        return 0;
        break;
    case encoder_enuRequestedValueTV:
        return Salva_Encoder.encoder_u16TidalVolume;
        break;
    case encoder_enuRequestedValueRR:
        return Salva_Encoder.encoder_u8RespiratoryRate;
        break;
    case encoder_enuRequestedValueEX:
        return Salva_Encoder.encoder_u8IERatioExpiratoryValue;
        break;
    default:
        /* Do Nothing */
        break;
    }
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Get Value", true);
}
