#include "Arduino.h"
#include "encoder_interface.h"

void SalvaEncoder::encoder_voidInit(void)
{
    pinMode(encoder_u8SWPin, INPUT);
}

void SalvaEncoder::encoder_voidInputTemplate(u16 Copy_u16BaseInput, u8 Copy_u8Multiplier, u16 Copy_u16MaximumInput, u16 Copy_ActualReading)
{
    encoder_u16BaseReading = 0;
    while (!digitalRead(encoder_u8SWPin))
    {
        static u16 Local_u16Position = Copy_u16BaseInput;
        SalvaEncoder::tick();
        encoder_u16BaseReading += (SalvaEncoder::getPosition() * Copy_u8Multiplier);
        if (Local_u16Position != encoder_u16BaseReading)
        {
            Serial.print("Reading = ");
            Serial.println(encoder_u16BaseReading);
            Serial.print("Direction: ");
            Serial.println((s8)(encoder.getDirection()));
            Local_u16Position = encoder_u16BaseReading >= Copy_u16MaximumInput ? Copy_u16MaximumInput : encoder_u16BaseReading;
        }
    }
    Copy_ActualReading = encoder_u16BaseReading;
}

void SalvaEncoder::encoder_voidGetTidalVolume(void)
{
    encoder_voidInputTemplate(encoder_u16TVBaseValue, encoder_u8TVMultiplier, encoder_u16TVMaximumValue, SalvaEncoder::encoder_u16TidalVolume);
}

void SalvaEncoder::encoder_voidGetRespiratoryRate(void)
{
    encoder_voidInputTemplate(encoder_u8RRBaseValue, encoder_u8RRMultiplier, encoder_u8RRMaximumValue, SalvaEncoder::encoder_u8RespiratoryRate);
}

void SalvaEncoder::encoder_voidGetIERatioExpiratoryValue(void)
{
    encoder_voidInputTemplate(encoder_enuIERatioInspiratoryValue, encoder_enuIERatioMultiplier, encoder_enuIERatioExpiratoryValueAbnormal2, SalvaEncoder::encoder_u8IERatioExpiratoryValue);
}
