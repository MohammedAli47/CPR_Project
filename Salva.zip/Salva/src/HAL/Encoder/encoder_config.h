#ifndef ENCODER_CONFIG_H_
#define ENCODER_CONFIG_H_

#define encoder_u8SWPin     4
#define encoder_u8DTPin     3
#define encoder_u8CLKPin    2

#endif
