#ifndef ENCODER_INTERFACE_H_
#define ENCODER_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "encoder_config.h"
#include "encoder_private.h"
#include "HAL/LCD/liquidCrystal_interface.h"
#include <RotaryEncoder.h>

class SalvaEncoder : public RotaryEncoder
{
private:
    u16 encoder_u16BaseReading, encoder_u16TidalVolume;
    u8 encoder_u8RespiratoryRate, encoder_u8IERatioExpiratoryValue;

public:
    SalvaEncoder() : RotaryEncoder(encoder_u8DTPin, encoder_u8CLKPin, RotaryEncoder::LatchMode::TWO03) {}
    void encoder_voidInit();
    void encoder_voidInputTemplate(u16 Copy_u16BaseInput, u8 Copy_u8Multiplier, u16 Copy_u16MaximumInput, u16 Copy_ActualReading);
    u16 encoder_u16GetValue(u8 Copy_u8RequestedValue);
};

extern SalvaEncoder Salva_Encoder;

#endif
