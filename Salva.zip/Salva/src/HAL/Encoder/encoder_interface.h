#ifndef ENCODER_INTERFACE_H_
#define ENCODER_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "encoder_config.h"
#include "encoder_private.h"
#include <RotaryEncoder.h>

class SalvaEncoder : public RotaryEncoder
{
public:
    u16 encoder_u16BaseReading, encoder_u16TidalVolume;
    u8 encoder_u8RespiratoryRate, encoder_u8IERatioExpiratoryValue;
    void encoder_voidInit(void);
    void encoder_voidInputTemplate(void);
    void encoder_voidGetTidalVolume(void);
    void encoder_voidGetRespiratoryRate(void);
    void encoder_voidGetIERatioExpiratoryValue(void);
};

#endif

// SalvaEncoder encoder(encoder_u8DTPin, encoder_u8CLKPin, RotaryEncoder::LatchMode::TWO03);
