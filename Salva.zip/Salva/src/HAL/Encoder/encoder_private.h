#ifndef ENCODER_PRIVATE_H_
#define ENCODER_PRIVATE_H_

#define encoder_u16TVMinValue       300
#define encoder_u8TVMultiplier      20
#define encoder_u16TVMaximumValue   700
#define encoder_u8RRMinValue        8
#define encoder_u8RRMultiplier      1
#define encoder_u8RRMaximumValue    20

typedef enum
{
    encoder_enuIERatioMultiplier = 1,
    encoder_enuIERatioInspiratoryValue = 1,
    encoder_enuIERatioExpiratoryValueNormal1,
    encoder_enuIERatioExpiratoryValueNormal2,
    encoder_enuIERatioExpiratoryValueAbnormal1,
    encoder_enuIERatioExpiratoryValueAbnormal2
} encoder_enuIERatioInspiratoryValues;

typedef enum
{
    encoder_enuNoRequestedValue,
    encoder_enuRequestedValueTV,
    encoder_enuRequestedValueRR,
    encoder_enuRequestedValueEX
} encoder_enuRequestedValues;

#define encoder_voidInputTidalVolume(w, x, y, z) Salva_Encoder.encoder_voidInputTemplate(w, x, y, z)
#define encoder_voidInputRespiratoryRate(w, x, y, z) Salva_Encoder.encoder_voidInputTemplate(w, x, y, z)
#define encoder_voidInputIERatioExpiratoryValue(w, x, y, z) Salva_Encoder.encoder_voidInputTemplate(w, x, y, z)

#endif
