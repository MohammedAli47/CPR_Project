#ifndef STEPPERMOTOR_CONFIG_H_
#define STEPPERMOTOR_CONFIG_H_

#define stepperMotor_u8PULPin 3
#define stepperMotor_u8DIRPin 2

#endif
