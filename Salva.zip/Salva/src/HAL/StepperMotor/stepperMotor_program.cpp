#include "Arduino.h"
#include "stepperMotor_interface.h"

void stepperMotor_voidInit()
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Stepper Motor Initializer");
    pinMode(stepperMotor_u8PULPin, OUTPUT);
    pinMode(stepperMotor_u8DIRPin, OUTPUT);
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Stepper Motor Initializer", false);
}

void stepperMotor_voidMotorDriver(u8 Copy_u8NumberOfRotations)
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Motor Driver Initializer");
    digitalWrite(stepperMotor_u8DIRPin, HIGH);
    for (u32 Local_u32Steps = 0; Local_u32Steps < stepperMotor_u16OneFullRotation * Copy_u8NumberOfRotations; Local_u32Steps++)
    {
        digitalWrite(stepperMotor_u8PULPin, HIGH);
        delayMicroseconds(stepperMotor_u16Delay);
        digitalWrite(stepperMotor_u8PULPin, LOW);
        delayMicroseconds(stepperMotor_u16Delay);
    }
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Motor Driver Initializer", false);
}
