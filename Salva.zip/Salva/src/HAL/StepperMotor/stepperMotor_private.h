#ifndef STEPPERMOTOR_PRIVATE_H_
#define STEPPERMOTOR_PRIVATE_H_

#define stepperMotor_u8StepsPerRotation         3200
#define stepperMotor_u8NumberOfRotationsMODE1   120
#define stepperMotor_u8NumberOfRotationsMODE2   30
#define stepperMotor_u8MicroSteppingMode1       1
#define stepperMotor_u8MicroSteppingMode2       2
#define stepperMotor_u8MicroSteppingMode4       4
#define stepperMotor_u8MicroSteppingMode8       8
#define stepperMotor_u8MicroSteppingMode16      16
#define stepperMotor_u8MicroSteppingMode32      32
#define stepperMotor_u16Delay                   (150/4)
#define stepperMotor_u16OneFullRotation         (stepperMotor_u8MicroSteppingMode1 * stepperMotor_u8StepsPerRotation)

#endif
