#ifndef STEPPERMOTOR_INTERFACE_H_
#define STEPPERMOTOR_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "stepperMotor_config.h"
#include "stepperMotor_private.h"

void stepperMotor_voidInit(void);
void stepperMotor_voidMotorDriver(u8 Copy_u8NumberOfRotations);

#endif
