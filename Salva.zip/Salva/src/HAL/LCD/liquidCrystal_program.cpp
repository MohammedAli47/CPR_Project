#include "Arduino.h"
#include "liquidCrystal_interface.h"

SalvaLiquidCrystal Salva_LCD;

void SalvaLiquidCrystal::liquidCrystal_voidInit(void)
{
    Salva_Debugger.errorTypes_enuDebuggerBeforeVoidFunction("Liquid Crystal Initializer");
    Salva_LCD.init();
    Salva_LCD.backlight();
    Salva_Debugger.errorTypes_enuDebuggerAfterVoidFunction("Liquid Crystal Initializer", true);
}

void SalvaLiquidCrystal::liquidCrystal_voidPositionUpdate(u8 Copy_u8Column, u8 Copy_u8Row)
{
    Salva_LCD.setCursor(Copy_u8Column, Copy_u8Row);
    Salva_LCD.liquidCrystal_u8ColumnNumber = Copy_u8Column;
    Salva_LCD.liquidCrystal_u8RowNumber = Copy_u8Row;
}
