#include "Arduino.h"
#include "liquidCrystal_interface.h"

void SalvaLiquidCrystal::liquidCrystal_voidInit(void)
{
    SalvaLiquidCrystal::init();
    SalvaLiquidCrystal::backlight();
}

template<typename _typenameArgument>
void SalvaLiquidCrystal::liquidCrystal_voidUpdateDisplay(u8 Copy_u8ArgumentCount, ...)
{
    va_list Local_VaList;
    va_start(Local_VaList, Copy_u8ArgumentCount);
    for (u8 Local_u8RowNumber = 0; Local_u8RowNumber < Copy_u8ArgumentCount; Local_u8RowNumber++)
    {
        SalvaLiquidCrystal::setCursor(0, Local_u8RowNumber);
        SalvaLiquidCrystal::print(va_arg(Local_VaList, _typenameArgument));
    }
    va_end(Local_VaList);
}
