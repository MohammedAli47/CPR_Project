#ifndef LIQUIDCRYSTAL_INTERFACE_H_
#define LIQUIDCRYSTAL_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "liquidCrystal_config.h"
#include "liquidCrystal_private.h"
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

class SalvaLiquidCrystal : public LiquidCrystal_I2C
{
public:
    void liquidCrystal_voidInit(void);
    template<typename _typenameArgument> void liquidCrystal_voidUpdateDisplay(u8 Copy_u8ArgumentCount, ...);
};

#endif
