#ifndef LIQUIDCRYSTAL_INTERFACE_H_
#define LIQUIDCRYSTAL_INTERFACE_H_
#include "LIB/stdTypes.h"
#include "LIB/errorTypes.h"
#include "liquidCrystal_config.h"
#include "liquidCrystal_private.h"
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

class SalvaLiquidCrystal : public LiquidCrystal_I2C
{
public:
    u8 liquidCrystal_u8ColumnNumber = 0, liquidCrystal_u8RowNumber = 0;
    SalvaLiquidCrystal() : LiquidCrystal_I2C(liquidCrystal_u8LCDSlaveAddress, liquidCrystal_u8NumberOfColumns, liquidCrystal_u8NumberOfRows) {}
    void liquidCrystal_voidInit(void);
    void liquidCrystal_voidPositionUpdate(u8 Copy_u8Column, u8 Copy_u8Row);
};

extern SalvaLiquidCrystal Salva_LCD;

#endif
