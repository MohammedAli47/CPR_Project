#ifndef LIQUIDCRYSTAL_PRIVATE_H_
#define LIQUIDCRYSTAL_PRIVATE_H_

#define liquidCrystal_u8LCDSlaveAddress 0x27

#endif
