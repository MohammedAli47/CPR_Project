#ifndef LIQUIDCRYSTAL_PRIVATE_H_
#define LIQUIDCRYSTAL_PRIVATE_H_

#define liquidCrystal_u8LCDSlaveAddress     0x27
#define liquidCrystal_boolNoAutoScroll      false
#define liquidCrystal_boolAutoScroll        true
#define liquidCrystal_boolNoClearDisplay    false
#define liquidCrystal_boolClearDisplay      true

// Not Used But Might Be In Future Updates
typedef enum
{
    liquidCrystal_enumColumnNumber1,
    liquidCrystal_enumColumnNumber2,
    liquidCrystal_enumColumnNumber3,
    liquidCrystal_enumColumnNumber4,
    liquidCrystal_enumColumnNumber5,
    liquidCrystal_enumColumnNumber6,
    liquidCrystal_enumColumnNumber7,
    liquidCrystal_enumColumnNumber8,
    liquidCrystal_enumColumnNumber9,
    liquidCrystal_enumColumnNumber10,
    liquidCrystal_enumColumnNumber11,
    liquidCrystal_enumColumnNumber12,
    liquidCrystal_enumColumnNumber13,
    liquidCrystal_enumColumnNumber14,
    liquidCrystal_enumColumnNumber15,
    liquidCrystal_enumColumnNumber16,
    liquidCrystal_enumColumnNumber17,
    liquidCrystal_enumColumnNumber18,
    liquidCrystal_enumColumnNumber19,
    liquidCrystal_enumColumnNumber20
} liquidCrystal_enumColumnNumbers;

typedef enum
{
    liquidCrystal_enumRowNumber1,
    liquidCrystal_enumRowNumber2,
    liquidCrystal_enumRowNumber3,
    liquidCrystal_enumRowNumber4
} liquidCrystal_enumRowNumbers;

#endif
