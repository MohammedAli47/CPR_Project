#ifndef LIQUIDCRYSTAL_CONFIG_H_
#define LIQUIDCRYSTAL_CONFIG_H_

#define liquidCrystal_u8NumberOfColumns 20
#define liquidCrystal_u8NumberOfRows    4

#endif